package com.deloitte.demo.services;
import com.deloitte.demo.model.Signin;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.deloitte.demo.dao.SigninDAO;
import com.deloitte.demo.model.Signin;

@Service
public class SigninService {
	
	@Autowired
	SigninDAO dao;

	
	public Signin validateUser(String userId, String password) {
		// TODO Auto-generated method stub
		return dao.validateUser(userId,password);
	}
	
	


	public String validate(String uname, String pwd) {
		// TODO Auto-generated method stub
		if(uname.equals("admin")&&pwd.equals("admin"))
		return "valid user";
		else
			return "invalid user";
	}
	
	
	public boolean validates(String uname, String pwd) {
		// TODO Auto-generated method stub
		if(uname.equals("admin")&&pwd.equals("admin"))
		return true;
		else
			return false;
	}

}
