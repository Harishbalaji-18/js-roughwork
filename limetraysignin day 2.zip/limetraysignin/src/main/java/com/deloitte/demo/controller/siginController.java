package com.deloitte.demo.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.deloitte.demo.model.Signin;
import com.deloitte.demo.services.SigninService;

@Controller
public class siginController {

	@Autowired
	SigninService service;
	
	@GetMapping("/msg")
	public ModelAndView myMethod()
	{
		ModelAndView modelandview=new ModelAndView();
		 modelandview.setViewName("index");
		// modelandview.addObject("test",service.getUser());
		 return modelandview;
		
	}
	
	
	@GetMapping("/form")
	
		public ModelAndView login()
		{
			ModelAndView modelandView=new ModelAndView();
			modelandView.setViewName("login");
			return modelandView;
		}
	
	@GetMapping("/login")
	
		public ModelAndView login(@RequestParam("uname") String uname,@RequestParam("pwd")String pwd)
		{
		ModelAndView check=new ModelAndView();
		if(service.validates(uname, pwd))
		{
			check.setViewName("index");
			return check;
			
		}
		else
		{
		check.setViewName("login");
			return check.addObject("test",service.validate(uname, pwd));
		}
		}
	
	
	//restaurant
	
	
	@GetMapping("/resort")
	public ModelAndView fn8(@RequestParam("veg chopsey")String veg chopsey)
	{
		ModelAndView checker=new ModelAndView();
		if(restaurant.validates(veg chopsey))
	
	
		
		
	
	
	
	
	@RequestMapping("/")
	public String getUser()
	{
		return "display message";
	}
	
	@RequestMapping("/login")
	public  Signin ValidateUser(@RequestParam("userId") String userId,@RequestParam("password")String password) {
		return service.validateUser(userId,password);
	}
	
}
