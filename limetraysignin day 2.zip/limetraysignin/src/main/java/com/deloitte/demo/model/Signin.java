package com.deloitte.demo.model;

import org.springframework.stereotype.Component;

@Component
public class Signin {
private String userId;
@Override
public String toString() {
	return "Signin [userId=" + userId + ", password=" + password + "]";
}


public String getUserId() {
	return userId;
}
public void setUserId(String userId) {
	this.userId = userId;
}
public String getPassword() {
	return password;
}
public void setPassword(String password) {
	this.password = password;
}
private String password;

}