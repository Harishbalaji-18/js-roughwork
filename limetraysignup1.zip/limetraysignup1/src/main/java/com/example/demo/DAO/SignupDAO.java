package com.example.demo.DAO;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

import org.springframework.stereotype.Repository;

import com.demo.example.model.Admin;

@Repository

public class SignupDAO {

	public static Connection connectToDB() {
		Connection connection = null;
		try {
			Class.forName("oracle.jdbc.driver.OracleDriver");
		} catch (ClassNotFoundException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
		try {
			connection = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe", "system", "admin");
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return connection;

	}

	public ArrayList<Admin> displayUser() {
		ArrayList<Admin> userList = new ArrayList<Admin>();
		try {
			Connection con = connectToDB();
			PreparedStatement stmt = con.prepareStatement("select * from signup");
			
			ResultSet rs = stmt.executeQuery();
			while (rs.next()) {
				Admin user = new Admin();
                     user.setName(rs.getString(1));
                     user.setUserid(rs.getString(2));
                     user.setPhone(rs.getInt(3));
                     user.setEmail(rs.getString(4));
                     System.out.println(user);
				userList.add(user);
			}
			// Step 5:Close Connection
			con.close();

		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		return userList;

	}
}

