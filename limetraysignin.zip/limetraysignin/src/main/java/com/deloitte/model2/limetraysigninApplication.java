package com.deloitte.model2;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class limetraysigninApplication {
	public static void main(String[] args) {
		SpringApplication.run(limetraysigninApplication.class, args);
	}

}
