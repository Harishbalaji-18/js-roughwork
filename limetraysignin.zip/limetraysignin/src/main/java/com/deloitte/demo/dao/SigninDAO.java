package com.deloitte.demo.dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

import org.springframework.stereotype.Repository;

import com.deloitte.demo.model.Signin;



@Repository
public class SigninDAO {

			public static Connection connectToDB() {
			Connection connection = null;
			// Step 1: Register the driver.

		try {
				Class.forName("oracle.jdbc.driver.OracleDriver");

				// Step 2: Create connection
				connection = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe", "system", "admin");
				return connection;
			} catch (ClassNotFoundException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
				return null;
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
				return null;
			}

		}

	



public Signin validateUser(String userId, String password) {
	// TODO Auto-generated method stub
	Signin user=new Signin();
	try {
		Connection con = connectToDB();
		PreparedStatement stmt = con.prepareStatement("select * from Signin where userId=? AND password=?");
		// execute sql query
		ResultSet rs = stmt.executeQuery();
		while (rs.next()) {
			user.setUserId(rs.getString(1));
			user.setPassword(rs.getString(2));
		}
		con.close();
		return user;
	} catch (SQLException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
	return null;
}

	
}


