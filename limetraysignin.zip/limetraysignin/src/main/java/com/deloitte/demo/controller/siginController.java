package com.deloitte.demo.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;


import com.deloitte.demo.model.Signin;
import com.deloitte.demo.services.SigninService;

@Controller
public class siginController {

	@Autowired
	SigninService service;
	
	@RequestMapping("/login")
	public  Signin ValidateUser(@RequestParam("userId") String userId,@RequestParam("password")String password) {
		return service.validateUser(userId,password);
	}
	
}
