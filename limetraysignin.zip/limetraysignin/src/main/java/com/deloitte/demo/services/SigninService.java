package com.deloitte.demo.services;
import com.deloitte.demo.model.*;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.deloitte.demo.dao.SigninDAO;
import com.deloitte.demo.model.Signin;

@Service
public class SigninService {
	
	@Autowired
	SigninDAO dao;

	
	public Signin validateUser(String userId, String password) {
		// TODO Auto-generated method stub
		return dao.validateUser(userId,password);
	}

}
